import java.util.Scanner;

public class  RemoveWord {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.print("Enter a string: ");
        String inputString = scn.nextLine();
        System.out.print("Enter the word to remove: ");
        String wordToRemove = scn.nextLine();
        scn.close();

        String result = removeWord(inputString, wordToRemove);
        System.out.println("Result after removing the word: " + result);
    }

    public static String removeWord(String str, String wordToRemove) {
        // Replace all occurrences of the word with an empty string
        String result = str.replaceAll("\\b" + wordToRemove + "\\b", "");
        // Trim leading and trailing spaces
        result = result.trim();
        // Replace multiple spaces with single space
        result = result.replaceAll("\\s+", " ");
        return result;
    }
}
