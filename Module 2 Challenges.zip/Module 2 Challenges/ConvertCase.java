import java.util.Scanner;

public class ConvertCase {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.print("Enter a string: ");
        String input = scn.nextLine();
        scn.close();

        String upperCase = convertToUpperCase(input);
        System.out.println("Uppercase: " + upperCase);

        String lowerCase = convertToLowerCase(input);
        System.out.println("Lowercase: " + lowerCase);
    }

    public static String convertToUpperCase(String input) {
        char[] chars = input.toCharArray();
        StringBuilder result = new StringBuilder();

        for (char c : chars) {
            if (c >= 'a' && c <= 'z') {
                result.append((char) (c - 32)); // convert lowercase to uppercase
            } else {
                result.append(c);
            }
        }

        return result.toString();
    }

    public static String convertToLowerCase(String input) {
        char[] chars = input.toCharArray();
        StringBuilder result = new StringBuilder();

        for (char c : chars) {
            if (c >= 'A' && c <= 'Z') {
                result.append((char) (c + 32)); // convert uppercase to lowercase
            } else {
                result.append(c);
            }
        }

        return result.toString();
    }
}
