import java.util.Scanner;

public class RepeatedCharacters {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a string: ");
        String input = scanner.nextLine();
        scanner.close();

        System.out.println("Repeated characters:");
        printRepeatedCharacters(input);
    }

    public static void printRepeatedCharacters(String str) {
        // Iterate through each character in the string
        for (int i = 0; i < str.length(); i++) {
            char currentChar = str.charAt(i);

            // Check if the character is a letter or digit and occurs more than once in the string
            if (Character.isLetterOrDigit(currentChar) && str.indexOf(currentChar, i + 1) != -1) {
                System.out.println(currentChar);
                // Avoid printing the same character multiple times
                while (i + 1 < str.length() && str.charAt(i + 1) == currentChar) {
                    i++;
                }
            }
        }
    }
}
