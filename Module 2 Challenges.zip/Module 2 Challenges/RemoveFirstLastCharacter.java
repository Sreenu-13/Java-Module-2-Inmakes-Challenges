import java.util.Scanner;

public class RemoveFirstLastCharacter {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.print("Enter a string: ");
        String inputString = scn.nextLine();
        scn.close();

        String result = removeFirstLast(inputString);
        System.out.println("Result after removing first and last character: " + result);
    }

    public static String removeFirstLast(String str) {
        // Check if the string has at least two characters
        if (str.length() < 2) {
            return "";
        }

        // Remove the first and last characters
        return str.substring(1, str.length() - 1);
    }
}
