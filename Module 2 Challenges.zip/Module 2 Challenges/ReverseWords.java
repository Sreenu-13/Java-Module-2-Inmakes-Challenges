import java.util.Scanner;

public class ReverseWords {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a string: ");
        String input = scanner.nextLine();
        scanner.close();

        String reversedString = reverseWords(input);
        System.out.println("Reversed string: " + reversedString);
    }

    public static String reverseWords(String input) {
        String[] words = input.split("\\s+");
        StringBuilder reversedString = new StringBuilder();

        // Append words in reverse order
        for (int i = words.length - 1; i >= 0; i--) {
            reversedString.append(words[i]);
            if (i > 0) {
                reversedString.append(" "); // Append space between words
            }
        }

        return reversedString.toString();
    }
}
