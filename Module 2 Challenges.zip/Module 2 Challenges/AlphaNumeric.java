import java.util.Scanner;

public class AlphaNumeric {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.print("Enter an alphanumeric string: ");
        String input = scn.nextLine();
        scn.close();

        String digits = extractDigits(input);
        System.out.println("Digits in the input string: " + digits);
    }

    public static String extractDigits(String input) {
        StringBuilder digits = new StringBuilder();

        for (char c : input.toCharArray()) {
            // Check if the character is a digit
            if (Character.isDigit(c)) {
                digits.append(c);
            }
        }

        return digits.toString();
    }
}
